﻿using MG.Server.BL;
using MG.Server.Services;
using System.Text.Json.Serialization;

namespace MG.Server.Entities
{
    public class PlayerData : BaseData<PlayerData>
    {
        public string Type { get; set; }

        public UserData? User { get; set; }

        public ItemData Table { get; set; }
        public ItemData Hand { get; set; }

        public LocationData Avatar { get; set; }
        public LocationData Camera { get; set; }

        // Server-driven UI: the complete 2D panel this seat should see, as a tree the client renders
        // verbatim. Null = no panel for this seat. Rebuilt by the game flow on every action.
        public List<UiNode>? Screen { get; set; }

        [JsonIgnore] public AIAgent AIAgent { get; set; }

        public PlayerData() { }
        public PlayerData(GameData game):base()
        {
            Type = PlayerTypeEnum.EMPTY_SEAT;
            Avatar = new LocationData();
            Camera = new LocationData();
            Table = new ItemData("", null) { Name = "PLAYER TABLE" };
            Hand = new ItemData("", null) { Name = "PLAYER HAND" };
            if (game != null)
            {
                game.Players.Add(this);
            }
        }

        internal PlayerData SetCameraPosition(int x, int y, int z)
        {
            this.Camera.Position.X = x;
            this.Camera.Position.Y = y;
            this.Camera.Position.Z = z;

            return this;
        }

        internal PlayerData SetAvatarPosition(int x, int y, int z)
        {
            this.Avatar.Position.X = x;
            this.Avatar.Position.Y = y;
            this.Avatar.Position.Z = z;

            return this;
        }
    }

    

        public class PlayerTypeEnum
    {
        public const string OBSERVER = "OBSERVER";
        public const string EMPTY_SEAT = "EMPTY_SEAT";
        public const string HUMAN = "HUMAN";
        public const string AI = "AI";
        
    }

}