﻿using MG.Server.Services;
using System.Text;

namespace MG.Server.Entities
{
    public class BaseData<T> where T: BaseData<T>
    {
        public string Id { get; set; }
        public string? Name { get; set; }
        public Dictionary<string, string> Attributes { get; set; }

        public BaseData() {
            Id = Guid.NewGuid().ToString();
            Name = Utils.RandomName();
            Attributes = new Dictionary<string, string>();
        }

        internal T AddAttribute(string key)
        {
            return AddAttribute(key, "TRUE");
        }
        internal T AddAttribute(string key, string val)
        {
            // upsert: setting an attribute that already exists overwrites it (Dictionary.Add
            // would throw — e.g. re-setting an item's animNonce/tint on a later action).
            Attributes[key] = val;
            return (T)this;
        }
        internal T AddAttribute(string key, double val)
        {
            Attributes[key] = val.ToString();
            return (T)this;
        }

        internal double GetNumberAttribute(string key)
        {            
            return Convert.ToDouble(Attributes.GetValueOrDefault(key)!);
        }
        internal int GetIntAttribute(string key)
        {
            return Convert.ToInt32(Attributes.GetValueOrDefault(key)!);
        }
        internal string GetStringAttribute(string key)
        {
            return Attributes.GetValueOrDefault(key);
        }

        internal bool HaveAttribute(string key)
        {
            return Attributes.ContainsKey(key);
        }
        internal bool HaveAttribute(string key,string val)
        {
            return Attributes.ContainsKey(key) && Attributes.GetValueOrDefault(key)==val;
        }
        public override string ToString()
        {
            return Utils.ListProperties(this);
        }

        
    }
}
